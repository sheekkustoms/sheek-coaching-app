import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

interface SendEmailRequest {
  recipients: string[];
  recipient_user_ids?: string[];
  subject: string;
  body: string;
}

function buildBrandedHtml(subject: string, body: string): string {
  const lines = body.split("\n").map((l) => {
    if (l.trim() === "") return "<br/>";
    return `<p style="margin:0 0 14px 0;line-height:1.8;font-size:15px;color:#FFFFFF;">${l.replace(/</g, "&lt;").replace(/>/g, "&gt;")}</p>`;
  }).join("\n");

  return `<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1.0"/>
<title>${subject}</title>
</head>
<body style="margin:0;padding:0;background-color:#000000;font-family:Georgia,'Times New Roman',serif;">

<!-- Preheader (hidden) -->
<div style="display:none;max-height:0;overflow:hidden;opacity:0;color:transparent;height:0;width:0;">
  ${subject}
</div>

<!-- Wrapper -->
<table width="100%" cellpadding="0" cellspacing="0" style="background-color:#000000;min-height:100vh;">
<tr>
<td align="center" style="padding:40px 20px;">

<!-- Email container -->
<table width="600" cellpadding="0" cellspacing="0" style="max-width:600px;width:100%;background-color:#0a0a0a;border:1px solid rgba(212,175,55,0.22);">

<!-- Header / Logo -->
<tr>
<td style="padding:40px 40px 30px 40px;text-align:center;border-bottom:1px solid rgba(212,175,55,0.18);background:radial-gradient(ellipse at 50% 0%,rgba(212,175,55,0.10) 0%,transparent 70%);">
<table width="100%" cellpadding="0" cellspacing="0">
<tr>
<td align="center">
<div style="font-family:Georgia,serif;font-size:32px;font-weight:bold;color:#D4AF37;letter-spacing:0.02em;line-height:1;">
  SEWSHEEK
</div>
<div style="font-family:'Helvetica Neue',Arial,sans-serif;font-size:11px;font-weight:bold;color:#FFFFFF;letter-spacing:0.35em;text-transform:uppercase;margin-top:6px;">
  Mentorship
</div>
</td>
</tr>
</table>
</td>
</tr>

<!-- Subject line -->
<tr>
<td style="padding:36px 40px 0 40px;">
<div style="font-family:'Helvetica Neue',Arial,sans-serif;font-size:10px;font-weight:bold;color:#FF1493;letter-spacing:0.24em;text-transform:uppercase;margin-bottom:10px;">
  A Message From SewSheek Mentorship
</div>
<h1 style="font-family:Georgia,serif;font-size:26px;font-weight:bold;color:#FFFFFF;margin:0 0 28px 0;line-height:1.2;">
  ${subject}
</h1>
</td>
</tr>

<!-- Body -->
<tr>
<td style="padding:0 40px 36px 40px;">
${lines}
</td>
</tr>

<!-- Divider -->
<tr>
<td style="padding:0 40px;">
<div style="border-top:1px solid rgba(212,175,55,0.20);"></div>
</td>
</tr>

<!-- Footer -->
<tr>
<td style="padding:28px 40px 40px 40px;text-align:center;">
<p style="font-family:Georgia,serif;font-size:18px;font-style:italic;color:#D4AF37;margin:0 0 12px 0;">
  SewSheek Mentorship
</p>
<p style="font-family:'Helvetica Neue',Arial,sans-serif;font-size:11px;color:#8a8a8a;margin:0 0 4px 0;line-height:1.6;">
  This email was sent to you from the SewSheek Mentorship System.
</p>
<p style="font-family:'Helvetica Neue',Arial,sans-serif;font-size:11px;color:#8a8a8a;margin:0;line-height:1.6;">
  &copy; ${new Date().getFullYear()} SewSheek Mentorship. All rights reserved.
</p>
</td>
</tr>

</table>

</td>
</tr>
</table>

</body>
</html>`;
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const RESEND_API_KEY = Deno.env.get("MENTORSHIPSEWSHEEK");
    const FROM_EMAIL = Deno.env.get("FROM_EMAIL") ?? "SewSheek Mentorship <onboarding@resend.dev>";

    if (!RESEND_API_KEY) {
      return new Response(
        JSON.stringify({ error: "Email service is not configured. The MENTORSHIPSEWSHEEK secret needs to be set." }),
        { status: 503, headers: { ...corsHeaders, "Content-Type": "application/json" } },
      );
    }

    const { recipients, recipient_user_ids, subject, body } = await req.json() as SendEmailRequest;

    if (!recipients || recipients.length === 0) {
      return new Response(
        JSON.stringify({ error: "At least one recipient is required." }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } },
      );
    }
    if (!subject || !subject.trim()) {
      return new Response(
        JSON.stringify({ error: "Subject is required." }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } },
      );
    }
    if (!body || !body.trim()) {
      return new Response(
        JSON.stringify({ error: "Email body is required." }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } },
      );
    }

    // Get the sender's ID from the JWT
    const authHeader = req.headers.get("Authorization") ?? "";
    const token = authHeader.replace("Bearer ", "");
    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
    );

    let senderId: string | null = null;
    try {
      const { data: userData } = await supabase.auth.getUser(token);
      senderId = userData.user?.id ?? null;
    } catch {
      // If we can't get the user, we still send the email but log with null sender
    }

    const html = buildBrandedHtml(subject, body);

    // Send via Resend
    const resendResponse = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${RESEND_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        from: FROM_EMAIL,
        to: recipients,
        subject: `SewSheek Mentorship — ${subject}`,
        html: html,
        text: body,
      }),
    });

    if (!resendResponse.ok) {
      const errText = await resendResponse.text();
      // Log the failure
      await supabase.from("email_log").insert({
        sender_id: senderId,
        recipients: recipients,
        recipient_user_ids: recipient_user_ids ?? [],
        subject: subject,
        body: body,
        status: "failed",
        error_message: errText,
      });

      return new Response(
        JSON.stringify({ error: `Email service returned an error: ${errText}` }),
        { status: 502, headers: { ...corsHeaders, "Content-Type": "application/json" } },
      );
    }

    // Log the successful send
    await supabase.from("email_log").insert({
      sender_id: senderId,
      recipients: recipients,
      recipient_user_ids: recipient_user_ids ?? [],
      subject: subject,
      body: body,
      status: "sent",
    });

    return new Response(
      JSON.stringify({ success: true, recipients: recipients.length }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );
  } catch (err) {
    return new Response(
      JSON.stringify({ error: err.message }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );
  }
});
