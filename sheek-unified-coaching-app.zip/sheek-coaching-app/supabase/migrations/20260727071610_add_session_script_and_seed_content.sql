/*
# Add session_script field and seed all 12 weeks with curriculum content

1. Overview
   Adds a "session_script" column to mentor_week_plans — this is the full
   read-aloud script with key answers, teaching content, and talking points
   that the mentor reads from during each session. Then seeds all 12 weeks
   with complete curriculum content so the mentor has everything ready.

2. Modified Tables
   - `mentor_week_plans`
     - session_script (text) — the full session script with answers and content

3. Data
   - Inserts complete teaching plans for all 12 weeks including teaching
     objective, talking points, prep checklist, common struggles, mentor notes,
     and the full session script with key answers.
*/

ALTER TABLE mentor_week_plans
  ADD COLUMN IF NOT EXISTS session_script text;

INSERT INTO mentor_week_plans (week_number, teaching_objective, talking_points, prep_checklist, common_struggles, mentor_notes, session_script, updated_at) VALUES
(1,
 'Students will complete a full diagnostic of their business — revenue, costs, margins, time spent, and emotional energy — and identify the 3 biggest leaks draining profit right now.',
 'Welcome and set the container for 12 weeks together
Why the autopsy comes before any strategy
Walk through the Business Autopsy Worksheet
Revenue audit: where every dollar actually comes from
Cost audit: the hidden costs most makers miss
Time audit: how many hours go into each product
Emotional energy audit: what drains you vs. what fuels you
Identify the top 3 profit leaks
Set the intention for the program',
 'Print or open the Business Autopsy Worksheet
Have each student''s current product list and prices ready
Prepare a whiteboard or shared doc for the group
Review each student''s intake form before the call
Set a calm, non-judgmental tone — this is diagnosis, not blame',
 'Students feel ashamed of how disorganized their numbers are
Students don''t know their real costs and feel embarrassed
Students resist looking at the numbers because it feels overwhelming
Students try to skip the audit and jump to solutions
Students get defensive about pricing decisions they''ve already made',
 'This week is about creating safety. If students feel judged here, they''ll shut down for the rest of the program. Normalize mess — every maker starts with messy numbers. The goal is awareness, not perfection. Watch for the ones who go quiet — they need extra reassurance.',
 'OPENING (5 min):
"Welcome. For the next 12 weeks, we''re going to rebuild your business from the ground up. But before we build anything, we need to see what''s actually happening right now. Not what you wish was happening — what''s real. That''s what today is about. This is a judgment-free zone. We''re not here to feel bad about the past. We''re here to get honest so we can fix it."

THE AUTOPSY FRAMEWORK (10 min):
"There are 5 areas we''re going to audit today: Revenue, Costs, Time, Energy, and Leaks. Most makers only look at revenue and costs. But time and energy are just as important — if you''re making money but burning out, that''s not a sustainable business. Let''s walk through each one."

REVENUE AUDIT (10 min):
"Open your worksheet. In the revenue section, list every product you sell and how much revenue it brought in last month. Not estimates — real numbers. If you don''t know exactly, put your best guess and mark it with a question mark."
KEY QUESTION: "Which product brings in the most revenue? Which one brings in the least?"
KEY ANSWER: "Most makers discover that 80% of their revenue comes from 20% of their products. That''s normal. But it means 80% of your products are barely contributing — and they''re still costing you time and materials."

COST AUDIT (10 min):
"Now list every cost that goes into each product. Not just materials — include packaging, shipping supplies, platform fees, payment processing fees, and a portion of your tools and equipment. This is where most makers get a shock."
KEY ANSWER: "If your material cost is $8 and you''re selling for $25, you might think you''re making $17 profit. But after packaging ($2), fees ($1.50), shipping supplies ($1), and your time (which we''ll calculate next), your real profit might be $4. That''s the number that matters."

TIME AUDIT (10 min):
"How long does each product take you? Be honest. Include designing, sourcing materials, making, photographing, listing, and customer service. Most makers dramatically underestimate this."
KEY ANSWER: "If a product takes you 3 hours total and you''re making $4 profit on it, you''re earning $1.33 per hour. That''s not a business — that''s a hobby that costs you money."

ENERGY AUDIT (5 min):
"Which products energize you to make? Which ones drain you? Mark each one with a + or -. This isn''t fluffy — if you dread making something, you''ll procrastinate, quality will slip, and it''ll eat your time."

IDENTIFY LEAKS (10 min):
"Looking at all 5 areas, what are the top 3 things draining your business right now? Write them down. These are what we''re going to fix over the next 11 weeks."

CLOSING (5 min):
"Next week, we''re taking one of those leaks — pricing — and doing a full overhaul. Bring your cost audit with you. Your homework is to finish the autopsy worksheet and identify your top 3 leaks. See you next week."',
 now()),
(2,
 'Students will understand the True Cost Formula and be able to recalculate their pricing with confidence so every product pays for materials, time, overhead, and profit.',
 'Review the autopsy results from Week 1
Why makers undercharge (emotional + practical reasons)
The 5-part True Cost Formula: Materials + Labor + Overhead + Profit + Value
How to calculate your real hourly rate
Value-based vs. cost-based pricing
How to handle "that''s too expensive" without apologizing
Live pricing exercise with each student''s products',
 'Have each student''s cost audit from Week 1 ready
Prepare the Pricing Worksheet template
Pull 2-3 examples of good vs. underpriced listings
Have a calculator or spreadsheet ready
Review common pricing objections and responses',
 'Fear of raising prices and losing customers
Not knowing their real costs (carried over from Week 1)
Imposter syndrome around "premium" pricing
Belief that cheaper = more sales
Worry that existing customers will feel betrayed by price increases',
 'This is the hardest week emotionally. Raising prices feels like a risk. Validate the fear but don''t let it drive decisions. Use data, not feelings, to set prices. If a student gets stuck, ask: "If you couldn''t change the price, could you change the product to cost less to make?"',
 'OPENING (5 min):
"Last week we did the autopsy. Most of you found that your pricing wasn''t covering your real costs. Today we''re fixing that. By the end of this session, you''ll know exactly what to charge and why."

WHY MAKERS UNDERCHARGE (10 min):
"Here''s why most makers underprice: One, you don''t know your real costs. Two, you''re scared people won''t buy. Three, you compare your prices to mass-produced factory goods on Amazon. Four, you feel guilty charging for your time because you enjoy making things. All of these are understandable — and all of them are keeping you broke."

THE TRUE COST FORMULA (15 min):
"Write this down. True Price = Materials + Labor + Overhead + Profit Margin + Value Premium."
MATERIALS: "What you physically put into the product. Include waste — if you buy a yard of fabric and use half, the cost of the full yard goes into your pricing."
LABOR: "Your time at your real hourly rate. We''ll calculate that next. Minimum: $25/hour. If you''re skilled, $40-60/hour. You are not free labor."
OVERHEAD: "Everything it costs to run your business divided across your products. Tools, software, studio space, phone, internet. Add 15-20% to your materials+labor as overhead."
PROFIT MARGIN: "This is what''s left after everyone gets paid — including you. If there''s no profit margin, you don''t have a business, you have a job. Minimum 20-30%."
VALUE PREMIUM: "This is what makes you different. Custom work, small-batch, locally made, unique design. If you''re the only person making what you make, that has value. Don''t hide it."

CALCULATE HOURLY RATE (10 min):
"Take your desired monthly income. Divide by the hours you actually spend making (not scrolling, not emailing — making). That''s your hourly rate. If the number scares you, good. That means you''ve been undercharging."

LIVE PRICING EXERCISE (15 min):
"Pull up one product. Let''s price it together right now. Materials? Labor at your new rate? Add 20% overhead. Add 30% profit margin. What''s the number? How does that compare to what you''re charging now?"
KEY ANSWER: "Most students discover they''re charging 40-60% less than they should be. That''s not a small adjustment — that''s the difference between a business that works and one that slowly drains you."

HANDLING OBJECTIONS (10 min):
"When someone says ''that''s too expensive,'' here''s what you say: ''I understand. This is handmade in small batches with premium materials. Each piece takes [X hours] and I stand behind the quality. If you''re looking for something at a lower price point, I have [other product].'' Never apologize for your price. Never discount without changing the offer."

CLOSING (5 min):
"Your homework: recalculate pricing for your top 5 products using the True Cost Formula. Next week we''re looking at who''s actually buying from you and why."',
 now()),
(3,
 'Students will build a detailed customer avatar — not demographics, but psychographics — and understand exactly who buys from them, why, and what that customer values.',
 'Why "everyone" is not your customer
Demographics vs. psychographics (demographics are useless alone)
The Customer Avatar Worksheet
What your customer actually values (not what you think they value)
Where your customer hangs out online and offline
What language your customer uses to describe your product
The difference between browsers and buyers
Mapping your top 3 customer types',
 'Have each student''s sales data ready (who actually bought, not who browsed)
Print the Customer Avatar Worksheet
Pull 5-10 real customer reviews or messages
Prepare examples of good vs. vague customer avatars
Review each student''s current product line to connect it to the avatar',
 'Students say "my product is for everyone"
Students describe their customer using demographics only (age, gender, location)
Students confuse who they want to sell to with who actually buys
Students feel niching down means leaving money on the table
Students don''t know what their customers actually value',
 'Push back hard on "everyone is my customer." It''s the #1 reason makers stay small. Use their own sales data as proof — the customers who actually bought will have a clear pattern. If they can''t see it, help them see it by reading their reviews together.',
 'OPENING (5 min):
"Last week we fixed your pricing. This week we''re looking at who''s on the other side of that price tag. Because if you don''t know who your customer is, you can''t market to them, you can''t price for them, and you can''t build products they''ll love."

WHY "EVERYONE" IS NOT YOUR CUSTOMER (10 min):
"If everyone is your customer, no one is your customer. When you market to everyone, your message is so generic that it speaks to no one. The richest businesses speak to a specific person so clearly that person feels seen. That''s what we''re building today."

DEMOGRAPHICS VS. PSYCHOGRAPHICS (10 min):
"Demographics tell you what your customer is. Psychographics tell you who your customer is. ''Female, 30-45, lives in a city'' is a demographic. ''Values handmade over mass-produced, feels guilty buying things for herself, wants her home to feel curated not catalog-bought, follows 3 ceramicists on Instagram'' — that''s a psychographic. That''s the person you''re talking to."

THE CUSTOMER AVATAR (15 min):
"Open the worksheet. We''re going to build your customer avatar across 6 dimensions:
1. VALUES: What matters to them? Quality? Uniqueness? Story? Sustainability?
2. FEARS: What are they afraid of? Wasting money? Looking basic? Not being unique?
3. DESIRES: What do they secretly want? To feel cultured? To support real makers? To have things nobody else has?
4. LANGUAGE: How do they describe what you make? Do they say ''unique'' or ''one-of-a-kind''? Do they say ''gift'' or ''treat''?
5. WHERE: Where do they hang out? Instagram? Pinterest? Etsy? Local markets? Subreddit?
6. TRIGGER: What makes them buy? A gift occasion? A treat-yourself moment? Seeing it on someone they admire?"

USE REAL DATA (10 min):
"Pull up your last 10 customer reviews or messages. What words do they use? What did they say about why they bought? That''s your avatar talking. Write down the exact phrases — you''ll use them in your marketing."

KEY ANSWER: "Most makers discover their actual customer is nothing like who they thought they were selling to. You might think you''re selling to young trendsetters, but your reviews are all from 45-year-old moms buying gifts. That changes everything about how you market."

BROWSERS VS. BUYERS (5 min):
"Not everyone who follows you is a buyer. Some are browsers who like your photos. Some are other makers studying you. Your avatar is the person who actually opens their wallet. Market to them, not your followers."

CLOSING (5 min):
"Homework: complete the Customer Avatar Worksheet for your top customer type. Next week we''re building your offer suite — the products that serve this customer at every price point."',
 now()),
(4,
 'Students will design a 3-tier offer suite (entry, core, premium) so customers can buy at their comfort level and the business captures revenue at every price point.',
 'Why a single product limits your income
The 3-tier offer model: Entry, Core, Premium
How to design each tier for your specific customer
Pricing each tier relative to the others
The anchor effect: why having a premium tier makes your core tier sell more
How to transition existing products into the suite
What to remove from your line (the products that drain you)',
 'Have each student''s product list with new pricing from Week 2
Have their customer avatar from Week 3
Prepare the Offer Suite Worksheet
Pull examples of businesses with clear 3-tier structures
Review each student''s time/energy audit to identify products to cut',
 'Students want to keep every product they''ve ever made
Students resist creating a premium tier ("no one will pay that")
Students don''t know what to put in each tier
Students worry that an entry product will cannibalize their core
Students feel overwhelmed by the idea of creating new products',
 'The premium tier is the hardest sell. Students will resist it. The anchor effect is the key insight — the premium tier doesn''t need to sell well to work; it makes the core tier look reasonable. Use the "good, better, best" framing from any retail context.',
 'OPENING (5 min):
"Right now most of you have a flat product line. Everything''s at one price point. That means every customer has to make one decision: buy or don''t buy. Today we''re giving them a better choice: buy small, buy medium, or buy big. More doors = more sales."

WHY ONE PRODUCT LIMITS INCOME (10 min):
"When you have one product at one price, you''re leaving money on the table from two groups: the person who wants to spend less to try you out, and the person who wants to spend more for something special. The entry tier catches the first. The premium tier catches the second. The core tier is where most people land."

THE 3-TIER MODEL (15 min):
"ENTRY TIER: $15-50. Low commitment. Lets a new customer experience your work without risk. Could be a mini version, a sample, a digital guide, an accessory. Goal: get them in the door.
CORE TIER: $50-200. Your bread and butter. The product you''re known for. Priced using the True Cost Formula from Week 2. This is where 60-70% of your revenue comes from.
PREMIUM TIER: $200+. Your showpiece. Custom work, large pieces, limited editions, sets. Most people won''t buy this — and that''s fine. It exists to make the core tier look reasonable."

THE ANCHOR EFFECT (10 min):
"This is the secret. When you show a $400 custom piece next to a $85 standard piece, the $85 looks like a deal. Without the $400 piece, the $85 looks expensive. The premium tier isn''t there to sell — it''s there to make everything else sell. This is called the anchor effect. Every major retailer uses it."

DESIGN YOUR SUITE (15 min):
"Open the worksheet. For each tier, write what product fits, what it costs to make, what you''ll charge, and who it''s for. Use your customer avatar from last week — what would your entry customer buy to try you? What would your premium customer buy to go all in?"
KEY ANSWER: "If you can''t think of a premium product, ask: what would you make if price wasn''t a concern? What would be the most impressive version of what you do? That''s your premium tier."

WHAT TO CUT (10 min):
"Look at your time and energy audit from Week 1. Which products drain you and barely sell? Cut them. Every product you keep costs you time, storage, and mental energy. A lean line of 3 tiers beats a bloated line of 15 products."

CLOSING (5 min):
"Homework: map your 3-tier offer suite and identify 2 products to retire. Next week we''re creating content that sells — the posts, photos, and words that make people want to buy."',
 now()),
(5,
 'Students will understand the 4 types of content that sell and be able to plan a week of content that moves customers from awareness to purchase.',
 'Why most maker content doesn''t sell (pretty but pointless)
The 4 content types: Educate, Story, Proof, Offer
How to map content to the buyer''s journey
The 7-day content calendar template
How to write product descriptions that sell
Photography basics: lighting, angles, and context shots
Batching content to save time',
 'Have each student''s offer suite from Week 4
Prepare the Content Calendar Template
Pull 3 examples of maker content that converted well
Have each student''s top 3 product photos ready for review
Review their current social media or shop for content audit',
 'Students create content that''s pretty but doesn''t sell
Students don''t know what to post so they post nothing
Students spend hours on content with no sales results
Students confuse "aesthetic" with "effective"
Students don''t have a system so content is sporadic',
 'The biggest shift this week: content is not decoration, it''s sales. Every post should have a job. If it''s not educating, storytelling, proving, or offering, it''s wasted. Push students to think like a marketer, not an artist, when planning content.',
 'OPENING (5 min):
"Your content is your salesperson. It works while you sleep. But most maker content is pretty pictures with no strategy behind it. Today we''re fixing that. By the end, you''ll have a week of content planned that actually moves people toward buying."

WHY PRETTY DOESN''T SELL (10 min):
"A beautiful photo of your product gets likes. But likes don''t pay rent. The question isn''t ''is this pretty?'' — it''s ''does this move someone closer to buying?'' If the answer is no, it''s not content, it''s decoration. Decoration is fine, but don''t confuse it with selling."

THE 4 CONTENT TYPES (15 min):
"Every piece of content you post should be one of these:
1. EDUCATE: Teach something about your craft, your materials, your process. ''Did you know real leather develops a patina? Here''s why that''s beautiful.'' Builds authority.
2. STORY: Share why you make, who you are, a moment from your studio. People buy from people, not logos. Builds connection.
3. PROOF: Customer reviews, photos of your product in use, behind-the-scenes of an order being packed. Builds trust.
4. OFFER: Here''s what I made, here''s what it costs, here''s where to buy it. Builds revenue. Most makers skip this one because it feels salesy. Don''t."

THE BUYER''S JOURNEY (10 min):
"Awareness → Interest → Desire → Action. Educate hits awareness. Story hits interest. Proof hits desire. Offer hits action. If you only post offers, people tune out. If you never post offers, people never buy. You need all four."

THE 7-DAY CALENDAR (10 min):
"Here''s your template:
Mon: Educate (teach something about your craft)
Tue: Story (share a moment, a struggle, a win)
Wed: Proof (a customer review or in-use photo)
Thu: Educate or Story (alternate)
Fri: Offer (show a product, price it, link it)
Sat: Proof or Story (behind-the-scenes)
Sun: Offer or Educate (wrap the week)
This rotates through all 4 types. Copy this. Use it every week."

PRODUCT DESCRIPTIONS (5 min):
"Your product description is content too. Don''t just list dimensions. Tell them how it feels, why it matters, what problem it solves. ''Hand-stitched leather wallet that fits in your front pocket and gets better with age'' beats ''3.5x4 inch leather wallet, 6 card slots.''"

CLOSING (5 min):
"Homework: plan one week of content using the template. Write the captions, choose the photos. Next week we''re going deep on the platforms where you''ll post it."',
 now()),
(6,
 'Students will choose 2 primary platforms to master (instead of being mediocre on 5) and understand the specific strategy for each.',
 'Why being everywhere means being nowhere
The platform matrix: Instagram, Etsy, Pinterest, TikTok, your own site
How to choose your 2 platforms based on your customer avatar
Instagram strategy: Reels, Stories, grid, bio, highlights
Etsy strategy: SEO, photos, tags, reviews, ads
Pinterest strategy: pins, boards, keywords, consistency
What to ignore (the platforms that waste your time)',
 'Have each student''s customer avatar from Week 3
Have their content plan from Week 5
Prepare the Platform Decision Matrix worksheet
Pull examples of makers winning on each platform
Review each student''s current platform presence for audit',
 'Students want to be on every platform simultaneously
Students spread themselves thin and burn out
Students chase new platforms instead of mastering current ones
Students don''t understand the difference between platforms
Students waste time on platforms their customers don''t use',
 'The hardest part is convincing students to abandon platforms. They''ll resist. Use their customer avatar as the deciding factor — if your customer isn''t on TikTok, you don''t need TikTok. Mastery of one beats mediocrity on five.',
 'OPENING (5 min):
"Last week we planned content. This week we''re choosing where to put it. Here''s the hard truth: you cannot be great on 5 platforms. You can be great on 2. Today we''re choosing your 2 and building a strategy for each."

WHY BEING EVERYWHERE FAILS (10 min):
"Every platform has a learning curve, a content format, an algorithm, and an audience. If you try to master 5, you''ll be mediocre on all 5. Mediocre doesn''t sell. Pick 2. Become undeniable on them. Expand later — or don''t."

THE PLATFORM MATRIX (15 min):
"Let''s map the platforms:
INSTAGRAM: Visual, story-driven, good for building brand. Best for makers whose customer values aesthetics and story. Reels for reach, Stories for connection, grid for catalog.
ETSY: Search-driven, transactional. Best for makers whose customer is already searching to buy. SEO and photos matter most. Not a brand-building platform — a sales platform.
PINTEREST: Visual search engine, long shelf life. Best for makers whose customer plans purchases (home decor, weddings, gifts). Pins live for months, not hours.
TIKTIK: Video, trend-driven, high reach potential. Best for makers whose customer is under 35 and values entertainment + authenticity. High effort, high reward.
YOUR OWN SITE: Full control, no algorithm, highest profit margin. Best for makers with an existing audience. Hardest to build traffic but most valuable long-term."

CHOOSE YOUR 2 (10 min):
"Look at your customer avatar. Where do they hang out? That''s platform 1. Where do they go when they''re ready to buy? That''s platform 2. If your customer is a 45-year-old who buys gifts on Etsy, you don''t need TikTok. If your customer is 28 and discovers brands on Instagram Reels, that''s your platform."

KEY ANSWER: "For most makers, the winning combo is Instagram (brand building) + Etsy (sales). If you''re in home decor or wedding, swap Etsy for Pinterest. If you''re targeting under-30, swap Instagram for TikTok."

PLATFORM-SPECIFIC STRATEGY (10 min):
"INSTAGRAM: Post 3 Reels/week, daily Stories, update grid 2x/week. Bio must say what you make + link to shop. Use Highlights for reviews, process, FAQ.
ETSY: Optimize titles with keywords customers actually search. First photo must be scroll-stopping. Get reviews by delivering great product + handwritten note. Run small ads ($1-5/day) on your best listings."

WHAT TO IGNORE (5 min):
"If it''s not your 2 platforms, it''s a distraction. Don''t post to Facebook because you feel guilty. Don''t start a YouTube channel because someone said you should. Master your 2. That''s enough."

CLOSING (5 min):
"Homework: commit to your 2 platforms. Optimize your profiles on both. Next week we''re building the system that turns one-time buyers into repeat customers."',
 now()),
(7,
 'Students will build a post-purchase follow-up system that turns one-time buyers into repeat customers and referral sources.',
 'Why repeat customers are 5x more profitable than new ones
The post-purchase experience: what happens after they buy
The 5-touch follow-up sequence (thank you, check-in, review, offer, referral)
How to ask for reviews without being pushy
Creating a reason to come back (new collections, loyalty, restocks)
The referral system: making it easy and rewarding to refer',
 'Have each student''s current post-purchase process mapped out
Prepare the Follow-Up Sequence template
Pull examples of great post-purchase emails from other brands
Review each student''s current review collection process
Have their customer avatar ready to personalize the sequence',
 'Students focus only on getting new customers
Students have no follow-up system at all
Students feel awkward asking for reviews or referrals
Students don''t know what to say in follow-up emails
Students think the sale is the end, not the beginning',
 'This week reframes the entire business: the sale is the start, not the finish. Most makers vanish after the purchase. The ones who follow up build empires. Push students to see the 30 days after a sale as more important than the 30 days before.',
 'OPENING (5 min):
"You''ve been focused on getting customers. Today we flip that. The real money isn''t in the first sale — it''s in the second, third, and tenth. A customer who buys once is a transaction. A customer who buys five times is a business."

WHY REPEAT BEATS NEW (10 min):
"It costs 5x more to acquire a new customer than to keep an existing one. A repeat customer spends 67% more than a first-time buyer. They already trust you, they already know your quality, they don''t need to be convinced. Yet most makers spend 100% of their marketing effort on strangers and 0% on people who already bought from them."

THE POST-PURCHASE EXPERIENCE (10 min):
"What happens after someone buys from you? If the answer is ''nothing,'' you''re leaving money on the table. The unboxing, the packaging, the note inside, the email after — these are all marketing. A great unboxing experience gets shared on Instagram. That''s free marketing you''re not doing."

THE 5-TOUCH SEQUENCE (15 min):
"Here''s your follow-up system:
TOUCH 1 (Day 0): Thank you email. Confirm the order. Make them feel good about buying. ''You just supported a real human maker. Here''s what happens next.''
TOUCH 2 (Day 7): Check-in. Did it arrive? Do they love it? This is service, not sales. ''Just checking — did your order arrive? Is everything perfect?''
TOUCH 3 (Day 14): Review request. Now that they''ve had it for 2 weeks, ask for a review. Make it easy — link directly to the review page. ''If you''re loving your [product], would you take 30 seconds to share that with others?''
TOUCH 4 (Day 30): Soft offer. Introduce them to something else you make. ''Since you loved [product], I thought you''d like [related product]. Here''s 10% off as a thank-you for being a customer.''
TOUCH 5 (Day 60): Referral ask. ''If you know someone who''d love what I make, send them this link — you both get [reward].''"

ASKING FOR REVIEWS (5 min):
"Don''t be pushy. Don''t offer discounts for reviews (it cheapens them). Just ask, make it easy, and time it right — 2 weeks after delivery, when the excitement is still fresh. One line: ''If you''re enjoying your order, a quick review would mean the world to a small maker like me.''"

THE REFERRAL SYSTEM (5 min):
"Make referring effortless. Give them a link to share. Reward both sides — they get 10%, their friend gets 10%. Don''t overcomplicate it. The goal is to make sharing your work the easiest thing they do all day."

CLOSING (5 min):
"Homework: write your 5-touch email sequence. Set it up to send automatically if you can. Next week we''re working on your voice — how to sound like nobody else in your market."',
 now()),
(8,
 'Students will define their unique brand voice — the words, tone, and personality that make them unmistakable in a sea of similar makers.',
 'Why sounding like everyone else kills your brand
The Brand Voice Worksheet: tone, vocabulary, personality, values
Finding your voice from your customer avatar''s language
Voice consistency across platforms, emails, and packaging
The 3 voice archetypes: the Expert, the Friend, the Artist
Words to use and words to avoid
How to write a brand voice guide you''ll actually use',
 'Have each student''s customer avatar from Week 3
Pull their reviews and customer messages for language patterns
Prepare the Brand Voice Worksheet
Review their current content, emails, and product descriptions
Pull 3 examples of makers with strong, distinct voices',
 'Students copy other brands'' voice and sound generic
Students are afraid to be themselves because it feels vulnerable
Students don''t know what their voice is — it feels intangible
Students are inconsistent — professional on Etsy, casual on Instagram
Students think "professional" means stiff and corporate',
 'Voice is the most personal week. Students will feel exposed. Normalize the discomfort — being specific about who you are always feels risky. The goal is not a polished corporate voice, but a real, consistent one. Push them to sound like themselves on their best day.',
 'OPENING (5 min):
"There are 10,000 people making what you make. Same materials, similar designs, similar prices. So why would someone buy from you instead of them? Because of you. Your voice. Today we''re defining it."

WHY GENERIC VOICE FAILS (10 min):
"When you sound like everyone else, you become interchangeable. Customers can''t tell you apart from the next maker. They''ll buy from whoever''s cheaper. But when your voice is unmistakable — when someone reads your caption and knows it''s you before they see the name — you become the only option."

THE BRAND VOICE WORKSHEET (20 min):
"Four dimensions:
1. TONE: Are you warm or authoritative? Playful or serious? Calm or energetic? Pick 2 that feel like you. Not 5 — 2.
2. VOCABULARY: What words do you use? What words would you never use? If you''d say ''handcrafted'' but never ''artisanal,'' write that down. Your vocabulary is your fingerprint.
3. PERSONALITY: If your brand was a person at a dinner party, who are they? The quiet expert? The warm host? The passionate artist? This is your archetype.
4. VALUES: What do you believe in? Slow making? Honest pricing? Sustainable materials? Say it out loud in your voice."

USE YOUR CUSTOMER''S WORDS (10 min):
"Remember the reviews we read in Week 3? The words your customers use to describe your work — those are your words. If they say ''heirloom,'' you say ''heirloom.'' If they say ''made to last,'' you say ''made to last.'' Meet them in their language."

THE 3 ARCHETYPES (5 min):
"THE EXPERT: Authoritative, educational, precise. You teach. You share knowledge. Customers come to you to learn.
THE FRIEND: Warm, personal, conversational. You share your life. Customers feel like they know you.
THE ARTIST: Passionate, emotional, story-driven. You share your why. Customers buy the meaning, not just the product.
Most makers are a blend. Pick your primary and your secondary."

CONSISTENCY (5 min):
"Your voice should be the same on Instagram, in your Etsy descriptions, in your emails, on your packaging. If you''re the Friend on Instagram but the Expert on Etsy, customers feel the disconnect. Pick your voice and use it everywhere."

CLOSING (5 min):
"Homework: complete the Brand Voice Worksheet. Write 3 sample captions in your voice. Next week we''re turning that voice into visibility — becoming the name people know."',
 now()),
(9,
 'Students will build a visibility plan to become the recognized name in their niche — through collaborations, features, shows, and strategic exposure.',
 'Why being good isn''t enough — you have to be known
The 5 visibility channels: features, collaborations, shows, content, PR
How to pitch yourself for features and collaborations
The collaboration math: who to partner with and why
Craft shows and markets: which ones, how to prepare, what to bring
Building a press kit that makes journalists say yes
The 90-day visibility plan',
 'Have each student''s brand voice from Week 8
Prepare the Visibility Plan template
Pull examples of makers who got featured and how
Research upcoming craft shows and markets in each student''s region
Review each student''s current network and connections',
 'Students are good at making but invisible in their market
Students wait to be discovered instead of pursuing visibility
Students are afraid of rejection so they don''t pitch
Students don''t know who to collaborate with
Students think visibility is about luck, not strategy',
 'This week is about action. Visibility doesn''t happen by waiting. Push students to send the pitch, apply to the show, reach out to the collaborator. The fear of rejection is the only thing standing between them and being known. Reframe every "no" as a step toward "yes."',
 'OPENING (5 min):
"You''re good at what you do. But being good isn''t enough. There are good makers nobody''s ever heard of. Today we''re fixing that. We''re building a plan to make you the name people think of when they think of your craft."

WHY GOOD ISN''T ENOUGH (10 min):
"Talent gets you in the game. Visibility wins the game. The maker who''s 70% as good as you but 10x more visible will outsell you every time. That''s not fair, but it''s true. The good news: visibility is a skill you can build. It''s not luck. It''s not personality. It''s strategy."

THE 5 VISIBILITY CHANNELS (15 min):
"1. FEATURES: Getting your work featured on blogs, magazines, influencer accounts. Pitch with a story, not a product. ''Local maker turns [material] into [thing]'' beats ''check out my new product.''
2. COLLABORATIONS: Partner with a complementary maker. You make leather wallets, they make belts. You share audiences. You both win.
3. SHOWS & MARKETS: In-person visibility. Pick shows where your customer avatar shops, not where it''s convenient. Prepare: signage, display, payment, email signup, packaging.
4. CONTENT: The ongoing visibility engine. Your Instagram, your blog, your newsletter. This is the one you control completely.
5. PR: Getting press. Write a press kit. Find journalists who cover your niche. Pitch with a hook, not a plea."

HOW TO PITCH (10 min):
"Pitches fail because they''re about you, not the editor. A good pitch answers: Why now? Why this audience? Why you? ''I''m a ceramicist in [city] using locally-sourced clay to make [specific thing]. I saw your piece on [topic] and thought your readers would love [angle].'' Short, specific, relevant. Follow up once after a week. Move on if no response."

COLLABORATION MATH (5 min):
"Find makers who share your customer but don''t compete. If you make baby blankets, partner with someone who makes nursery decor. You''re not splitting customers — you''re doubling your reach. One collaboration = exposure to their entire audience for free."

CRAFT SHOWS (5 min):
"Choose shows where your customer shops. Not the biggest show — the right show. Invest in a display that photographs well (people will post it). Collect emails at every show. The show isn''t just for sales — it''s for list-building."

THE 90-DAY PLAN (5 min):
"Write down: 1 feature to pitch, 1 collaboration to pursue, 1 show to apply for, and a content plan to sustain. That''s your next 90 days. Execute one per month."

CLOSING (5 min):
"Homework: send 3 pitches this week. One to a blog, one to a collaborator, one to a show. Next week we start building your launch machine."',
 now()),
(10,
 'Students will design a launch system — the mechanics of taking a new product or collection from announcement to sale day with maximum demand.',
 'Why launches work (and why random product drops don''t)
The 14-day launch framework: Tease, Reveal, Build, Sell
Pre-launch: building the waitlist and warming the audience
Launch week: the daily content sequence
Scarcity and urgency (without being manipulative)
The post-launch debrief
Setting up your launch infrastructure (email, landing page, checkout)',
 'Have each student''s offer suite from Week 4
Have their content skills from Week 5 and platform from Week 6
Prepare the Launch Plan template
Pull examples of successful maker launches
Review each student''s email list size and engagement',
 'Students have never launched — they just list products
Students don''t build anticipation, they just announce
Students don''t collect emails before a launch
Students confuse a launch with a sale or discount
Students don''t follow up after launch to capture late buyers',
 'A launch is a campaign, not a post. The biggest mindset shift: you''re not dropping a product, you''re building demand for 2 weeks and releasing it on one day. Push students to think in sequences, not single posts.',
 'OPENING (5 min):
"For the last 9 weeks we''ve been building the foundation — pricing, offers, content, voice, visibility. Now we use all of it. Today we''re building your launch machine. A launch is a campaign, not a post. It''s 14 days of building demand for one moment of release."

WHY LAUNCHES WORK (10 min):
"When you just list a product, you''re hoping someone stumbles on it. When you launch, you''re creating a moment. People show up ready to buy. A launch creates urgency, anticipation, and momentum. It turns a product drop into an event."

THE 14-DAY FRAMEWORK (20 min):
"DAYS 1-4 — TEASE: Hint at something new. Don''t show the product. Show a detail, a material, a sketch. Build curiosity. ''Something''s coming. I''ve been working on this for months.''
DAYS 5-8 — REVEAL: Show the product. Tell the story. Why you made it, what makes it special, who it''s for. Don''t price it yet. Let them fall in love first.
DAYS 9-12 — BUILD: Share the process, the details, the options. Start collecting emails. ''Drop your email to get first access + a launch-day bonus.''
DAY 13 — LAST CALL: Tomorrow. Be ready. Set your alarm. Last chance to join the list for the bonus.
DAY 14 — LAUNCH: Product goes live. Email the list first. Post the offer. Make it easy to buy. Share the launch in real time."

SCARCITY WITHOUT MANIPULATION (5 min):
"If you have 10 of something, say 10. If it''s one-of-a-kind, say so. If the launch bonus ends at midnight, end it at midnight. Scarcity works when it''s true. Fake scarcity destroys trust. Never lie about quantities or deadlines."

PRE-LAUNCH INFRASTRUCTURE (10 min):
"You need 3 things ready before Day 1:
1. EMAIL LIST: A way to collect emails. Mailchimp, ConvertKit, even a Google Form. If you don''t have a list, start one today.
2. LANDING PAGE: A simple page that says what''s coming and collects the email. Can be a Linktree, a Shopify page, a Carrd.
3. CHECKOUT: Make buying frictionless. If it takes 5 clicks to buy, you''ll lose people. Test it yourself before launch day."

POST-LAUNCH (5 min):
"The launch isn''t over on Day 14. Days 15-21: follow up with people who opened emails but didn''t buy. Share photos of orders shipping. Capture the late buyers. Then debrief: what worked, what didn''t, what to change next time."

CLOSING (5 min):
"Homework: pick a product and map its 14-day launch. Write the email sequence. Next week is launch week — for real. We''re doing it together."',
 now()),
(11,
 'Students will execute their launch — going live with their product, managing the chaos in real time, and capturing every sale.',
 'Launch day checklist and timeline
Going live: the first post, the first email, the first sale
Managing real-time questions and objections
Selling out vs. restocking — how to handle both
Capturing launch day content for future marketing
The 48-hour follow-up sequence
Troubleshooting: what to do when things go wrong',
 'Have each student''s 14-day launch plan from Week 10
Verify all launch infrastructure is ready (email, landing page, checkout)
Prepare a launch day checklist for each student
Have backup plans for common launch day failures
Set up a group chat or check-in system for launch day support',
 'Students panic on launch day and freeze
Students don''t follow their plan and post randomly
Students get discouraged if sales are slow in the first hour
Students forget to capture content in the chaos
Students don''t follow up with people who showed interest but didn''t buy',
 'This is the week to be present and supportive. Launch day is emotional. Sales may come fast or slow. Normalize both. The students who follow the plan and follow up will win, even if launch day is imperfect. Done is better than perfect.',
 'OPENING (5 min):
"This is it. Launch week. Everything we''ve built for 10 weeks comes together now. Today isn''t about learning — it''s about executing. You have your plan. Now we run it."

LAUNCH DAY TIMELINE (15 min):
"Here''s your launch day, hour by hour:
T-MINUS 1 HOUR: Final check. Checkout works. Email is scheduled. Landing page is live. You''ve tested the buy button.
HOUR 0 — GO LIVE: Email the list first. They get the bonus. Post the launch on your primary platform. Story, Reel, post — all three.
HOUR 1-3: Be visible. Reply to every comment. Answer every DM. Post Stories showing the launch happening. Share the first sales.
HOUR 4-8: Keep the energy up. Post a behind-the-scenes. Share a customer''s reaction. Remind people the bonus ends at midnight.
HOUR 12: Last call post. ''12 hours in. [X] sold. Bonus ends in 12 hours.''
HOUR 24: Launch day wrap. Thank everyone. Share the final count. If you sold out, celebrate and tease restock. If you didn''t, the follow-up sequence starts tomorrow."

HANDLING OBJECTIONS IN REAL TIME (10 min):
"People will DM you with questions. ''Is it really handmade?'' ''Do you do custom?'' ''Will it fit?'' Answer fast, answer honestly, answer in your brand voice. Every unanswered DM is a lost sale. Have templates ready for the top 5 questions."

SOLD OUT VS. RESTOCKING (5 min):
"If you sell out: celebrate publicly, capture emails for restock, announce the restock date. Scarcity just became your friend.
If you don''t sell out: don''t panic. The follow-up sequence is where 30% of launch sales come from. Most buyers wait until the last day."

CAPTURING CONTENT (5 min):
"In the chaos, don''t forget to film. Packing the first order. The moment you hit ''publish.'' The first sale notification. This content is gold for your next launch. Have someone film you, or set up your phone on a tripod."

THE 48-HOUR FOLLOW-UP (10 min):
"DAY 2: Email people who opened but didn''t buy. ''Still thinking? Here''s what people are saying.'' Include a review or a photo.
DAY 3: Last chance email. ''Closing the launch tonight. Here''s your last chance for the bonus.'' This email always converts."

TROUBLESHOOTING (5 min):
"Checkout breaks? Have a backup — PayPal, Venmo, DM-to-buy. Email doesn''t send? Post on every platform. Nobody buys in hour 1? Don''t panic — most sales come in the last 6 hours. Follow the plan."

CLOSING (5 min):
"You''ve got this. Execute the plan. I''m here all week. Next week we debrief — what worked, what didn''t, and what we build next."',
 now()),
(12,
 'Students will debrief the full 12 weeks, review their launch results, and build a 90-day action plan to sustain momentum after the program ends.',
 'Reviewing the full 12-week journey
Launch debrief: what worked, what didn''t, what to repeat
The post-program 90-day action plan
Setting up systems that run without you
Building the next launch calendar
Community and ongoing support after the program
Celebration and closing ceremony',
 'Have each student''s launch results and metrics ready
Prepare the 90-Day Action Plan template
Review each student''s progress from Week 1 to Week 12
Prepare a closing recognition or certificate for each student
Set up an ongoing community space (group, newsletter, etc.)',
 'Students feel overwhelmed by everything they learned
Students don''t know what to prioritize after the program
Students worry they''ll lose momentum without the structure
Students feel sad the program is ending
Students haven''t implemented everything and feel behind',
 'This week is about celebration and momentum, not guilt. Not every student implemented everything. That''s fine. The goal is a clear 90-day plan they''ll actually follow, not a guilt trip about what they didn''t do. End on a high note.',
 'OPENING (5 min):
"12 weeks. You showed up. You did the work. You launched a product. Whether it sold out or sold one, you did something most makers never do — you treated your craft like a business. Today we celebrate that, and we build what comes next."

THE 12-WEEK REVIEW (10 min):
"Look back at your autopsy from Week 1. What were your top 3 leaks? How many have you fixed? Look at your pricing from Week 2. Have you raised it? Look at your offer suite from Week 4. Is it built? You don''t need to have done everything. But notice what you did. That''s progress."

LAUNCH DEBRIEF (15 min):
"Let''s look at your launch. How many sales? How much revenue? How many emails collected? What worked? What would you change? Write this down. Your next launch will be better because of this data, not despite it.
KEY ANSWER: A launch that makes $200 is not a failure. It''s a data point. You now know what works for your audience. The next launch builds on this. The third launch is where most makers see real momentum."

THE 90-DAY ACTION PLAN (15 min):
"You don''t need to do everything. Pick 3 things to focus on for the next 90 days. Here''s the menu:
- Fix your pricing on remaining products (Week 2)
- Build your 3-tier offer suite (Week 4)
- Post 3x/week using the content framework (Week 5)
- Send the 5-touch follow-up sequence to past customers (Week 7)
- Pitch 3 features or collaborations (Week 9)
- Plan and execute your next launch (Weeks 10-11)
Pick 3. Write them on your calendar. That''s your 90 days."

SYSTEMS THAT RUN WITHOUT YOU (5 min):
"The goal is a business that doesn''t need you every hour. Email sequences that send automatically. Content that you batch once a month. A follow-up system that runs on its own. Set these up now so your business works even when you''re making."

THE NEXT LAUNCH (5 min):
"Schedule your next launch today. Even if it''s 3 months out. Put it on the calendar. Work backward from it. A business without a next launch drifts. A business with a date on the calendar builds toward something."

CLOSING (5 min):
"You''re not done. You''re just starting. Everything we built here is a foundation. The next 12 months are where it compounds. Stay in the community. Share your wins. Ask for help. You''ve got this. I''m proud of you. Now go make."
CLOSING CEREMONY:
"Acknowledge each student by name. Share one thing you admired about their journey. Give them their recognition. End with the group''s energy high. This is not an ending — it''s a launch."',
 now())
ON CONFLICT (week_number) DO UPDATE SET
  teaching_objective = EXCLUDED.teaching_objective,
  talking_points = EXCLUDED.talking_points,
  prep_checklist = EXCLUDED.prep_checklist,
  common_struggles = EXCLUDED.common_struggles,
  mentor_notes = EXCLUDED.mentor_notes,
  session_script = EXCLUDED.session_script,
  updated_at = EXCLUDED.updated_at;
