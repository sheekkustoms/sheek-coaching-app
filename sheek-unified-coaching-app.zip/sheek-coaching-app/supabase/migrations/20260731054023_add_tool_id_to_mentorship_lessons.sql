ALTER TABLE mentorship_lessons ADD COLUMN IF NOT EXISTS tool_id text;
