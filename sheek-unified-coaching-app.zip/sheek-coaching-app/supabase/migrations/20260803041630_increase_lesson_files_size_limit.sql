-- Raise lesson-files bucket to 5 GB per file
UPDATE storage.buckets
SET file_size_limit = 5368709120
WHERE name = 'lesson-files';
