-- 1. Revoke UPDATE on privileged columns from authenticated users
--    Only admins should be able to change is_admin and permissions.
--    Regular users can still update their own display_name, avatar_url, etc.
REVOKE UPDATE ON profiles FROM authenticated;
GRANT UPDATE (display_name, avatar_url) ON profiles TO authenticated;

-- 2. Create a SECURITY DEFINER function that allows admins to set
--    permissions and admin status on any member
CREATE OR REPLACE FUNCTION set_member_role(
  p_member uuid,
  p_is_admin boolean DEFAULT false,
  p_permissions jsonb DEFAULT '{}'::jsonb
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
BEGIN
  -- Authorize the CALLER: must be an existing admin
  IF NOT EXISTS (
    SELECT 1 FROM profiles
    WHERE id = auth.uid() AND is_admin = true
  ) THEN
    RAISE EXCEPTION 'Not authorized';
  END IF;

  -- Prevent self-demotion (an admin cannot remove their own admin status)
  IF p_member = auth.uid() AND p_is_admin = false THEN
    RAISE EXCEPTION 'You cannot remove your own admin status';
  END IF;

  -- Validate permissions keys
  IF p_permissions IS NULL THEN
    p_permissions := '{}'::jsonb;
  END IF;

  -- Update the target member
  UPDATE profiles
  SET is_admin = p_is_admin,
      permissions = p_permissions
  WHERE id = p_member;
END;
$$;

-- 3. Revoke EXECUTE from anon, grant to authenticated
REVOKE EXECUTE ON FUNCTION set_member_role FROM anon;
GRANT EXECUTE ON FUNCTION set_member_role TO authenticated;
