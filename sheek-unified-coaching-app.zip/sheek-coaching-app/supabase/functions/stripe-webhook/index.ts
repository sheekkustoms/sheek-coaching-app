import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers":
    "Content-Type, Authorization, X-Client-Info, Apikey",
};

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const STRIPE_SECRET_KEY = Deno.env.get("STRIPE_SECRET_KEY");
    const STRIPE_WEBHOOK_SECRET = Deno.env.get("STRIPE_WEBHOOK_SECRET");

    if (!STRIPE_SECRET_KEY || !STRIPE_WEBHOOK_SECRET) {
      return new Response(
        JSON.stringify({ error: "Stripe webhook is not configured." }),
        { status: 503, headers: { ...corsHeaders, "Content-Type": "application/json" } },
      );
    }

    const rawBody = await req.text();
    const signature = req.headers.get("stripe-signature");

    let event;
    try {
      const stripeModule = await import("npm:stripe@14.25.0");
      const stripe = new stripeModule.default(STRIPE_SECRET_KEY);
      event = stripe.webhooks.constructEvent(
        rawBody,
        signature ?? "",
        STRIPE_WEBHOOK_SECRET,
      );
    } catch (err) {
      return new Response(
        JSON.stringify({ error: `Webhook signature verification failed: ${err.message}` }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } },
      );
    }

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
    );

    // One-time course purchase
    if (event.type === "checkout.session.completed") {
      const session = event.data.object;
      const userId = session.metadata?.user_id;
      const courseId = session.metadata?.course_id;

      if (userId && courseId) {
        const { error: insertError } = await supabase
          .from("course_purchases")
          .upsert(
            {
              user_id: userId,
              course_id: courseId,
              stripe_session_id: session.id,
              amount_paid: session.amount_total ?? null,
            },
            { onConflict: "user_id,course_id" },
          );

        if (insertError) {
          return new Response(
            JSON.stringify({ error: `Failed to record purchase: ${insertError.message}` }),
            { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } },
          );
        }
      }
    }

    // Mentorship subscription created / activated
    if (event.type === "checkout.session.completed" || event.type === "customer.subscription.created" || event.type === "customer.subscription.updated") {
      const obj = event.data.object;

      let userId: string | undefined;
      let subscriptionId: string | undefined;
      let customerId: string | undefined;
      let status: string | undefined;

      if (event.type === "checkout.session.completed") {
        // Only handle if this is a subscription checkout (no course_id metadata)
        const session = obj;
        if (session.metadata?.course_id) {
          // Already handled above as course purchase
        } else {
          userId = session.metadata?.user_id;
          subscriptionId = session.subscription as string | undefined;
          customerId = session.customer as string | undefined;
          status = "active";
        }
      } else {
        // customer.subscription.created / .updated
        const sub = obj;
        userId = sub.metadata?.user_id;
        subscriptionId = sub.id;
        customerId = sub.customer as string | undefined;
        status = sub.status;
      }

      if (userId && subscriptionId) {
        await supabase
          .from("mentorship_subscriptions")
          .upsert(
            {
              user_id: userId,
              stripe_subscription_id: subscriptionId,
              stripe_customer_id: customerId ?? null,
              status: status ?? "active",
            },
            { onConflict: "stripe_subscription_id" },
          );

        if (status === "active" || status === "trialing") {
          await supabase
            .from("profiles")
            .update({ tier: "mentorship" })
            .eq("id", userId);
        } else if (status === "canceled" || status === "unpaid" || status === "incomplete_expired") {
          await supabase
            .from("profiles")
            .update({ tier: "member" })
            .eq("id", userId);
        }
      }
    }

    // Subscription deleted — downgrade
    if (event.type === "customer.subscription.deleted") {
      const sub = event.data.object;
      const userId = sub.metadata?.user_id;
      if (userId) {
        await supabase
          .from("profiles")
          .update({ tier: "member" })
          .eq("id", userId);
        await supabase
          .from("mentorship_subscriptions")
          .update({ status: "canceled" })
          .eq("stripe_subscription_id", sub.id);
      }
    }

    return new Response(
      JSON.stringify({ received: true }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );
  } catch (err) {
    return new Response(
      JSON.stringify({ error: err.message }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );
  }
});
