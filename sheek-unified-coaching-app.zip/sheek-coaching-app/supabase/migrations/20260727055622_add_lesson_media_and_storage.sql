/*
# Add PDF/video support and lesson-files storage bucket

1. Modified Tables
   - `lessons`
     - pdf_url (text, nullable) — public URL of an uploaded PDF stored in the
       lesson-files bucket.
     - video_url (text, nullable) — external video URL (YouTube/Vimeo/etc.).

2. Storage
   - Create public bucket `lesson-files` for PDF uploads.
   - The bucket is public so the resulting file URLs are directly downloadable
     in the browser (academy content is shared among members).

3. Security
   - storage.objects SELECT policy for authenticated reads of lesson-files.
   - storage.objects INSERT policy for authenticated uploads to lesson-files.
*/

ALTER TABLE lessons ADD COLUMN IF NOT EXISTS pdf_url text;
ALTER TABLE lessons ADD COLUMN IF NOT EXISTS video_url text;

INSERT INTO storage.buckets (id, name, public)
VALUES ('lesson-files', 'lesson-files', true)
ON CONFLICT (id) DO NOTHING;

DROP POLICY IF EXISTS "auth_read_lesson_files" ON storage.objects;
CREATE POLICY "auth_read_lesson_files" ON storage.objects FOR SELECT
  TO authenticated USING (bucket_id = 'lesson-files');

DROP POLICY IF EXISTS "auth_upload_lesson_files" ON storage.objects;
CREATE POLICY "auth_upload_lesson_files" ON storage.objects FOR INSERT
  TO authenticated WITH CHECK (bucket_id = 'lesson-files');
