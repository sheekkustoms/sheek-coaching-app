import "jsr:@supabase/functions-js/edge-runtime.d.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
  "Cross-Origin-Resource-Policy": "cross-origin",
};

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  if (req.method !== "GET") {
    return new Response("Method not allowed", { status: 405, headers: corsHeaders });
  }

  const path = new URL(req.url).searchParams.get("path") ?? "";
  if (!/^[0-9a-f-]{36}\/avatar-[A-Za-z0-9._-]+\.(jpg|jpeg|png|webp)$/i.test(path)) {
    return new Response("Not found", { status: 404, headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    if (!supabaseUrl) {
      return new Response("Image unavailable", { status: 500, headers: corsHeaders });
    }

    const imageResponse = await fetch(
      `${supabaseUrl}/storage/v1/object/public/avatars/${path}`,
    );
    if (!imageResponse.ok || !imageResponse.body) {
      return new Response("Not found", { status: 404, headers: corsHeaders });
    }

    return new Response(imageResponse.body, {
      status: 200,
      headers: {
        ...corsHeaders,
        "Content-Type": imageResponse.headers.get("Content-Type") ?? "image/jpeg",
        "Cache-Control": "public, max-age=3600",
      },
    });
  } catch {
    return new Response("Image unavailable", { status: 500, headers: corsHeaders });
  }
});
