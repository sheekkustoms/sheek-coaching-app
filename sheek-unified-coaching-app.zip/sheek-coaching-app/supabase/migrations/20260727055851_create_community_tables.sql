/*
# Create profiles and posts tables for Community

1. Overview
   The Community tab shows a feed of member posts. Each post displays the
   author's display name, a relative timestamp, and the body text. Posts are
   linked to the logged-in user. Because Supabase Auth only stores email (not
   a display name), a `profiles` table (1:1 with auth.users) holds each
   member's display name. A trigger auto-creates a profile row on signup,
   defaulting the display name to the email's local part; existing users are
   backfilled.

2. New Tables
   - `profiles`
     - id (uuid, PK, REFERENCES auth.users(id) ON DELETE CASCADE) — 1:1 with users
     - display_name (text, not null)
     - created_at (timestamptz, default now())
   - `posts`
     - id (uuid, PK)
     - body (text, not null)
     - user_id (uuid, NOT NULL DEFAULT auth.uid(), REFERENCES profiles(id) ON DELETE CASCADE)
     - created_at (timestamptz, default now())

   posts.user_id references profiles(id) (which itself maps 1:1 to auth.users.id)
   so the feed can join posts -> profiles in a single nested select.

3. Automation
   - `handle_new_user()` trigger function (SECURITY DEFINER) inserts a profile
     row whenever a new auth.users row is created, defaulting display_name to
     the part of the email before "@".
   - Trigger `on_auth_user_created` fires AFTER INSERT on auth.users.

4. Backfill
   - Inserts profile rows for any existing auth.users who don't yet have one,
     using the email local part as the display name.

5. Security (RLS)
   - profiles: authenticated SELECT (members can see each other's names);
     owner-only UPDATE (auth.uid() = id). No insert/delete via client — the
     trigger manages inserts.
   - posts: authenticated SELECT (the feed is shared among members);
     owner-scoped INSERT/UPDATE/DELETE (auth.uid() = user_id).
*/

CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  display_name text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "auth_select_profiles" ON profiles;
CREATE POLICY "auth_select_profiles" ON profiles FOR SELECT
  TO authenticated USING (true);

DROP POLICY IF EXISTS "auth_update_own_profile" ON profiles;
CREATE POLICY "auth_update_own_profile" ON profiles FOR UPDATE
  TO authenticated USING (auth.uid() = id) WITH CHECK (auth.uid() = id);

CREATE TABLE IF NOT EXISTS posts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  body text NOT NULL,
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES profiles(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE posts ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "auth_select_posts" ON posts;
CREATE POLICY "auth_select_posts" ON posts FOR SELECT
  TO authenticated USING (true);

DROP POLICY IF EXISTS "auth_insert_own_posts" ON posts;
CREATE POLICY "auth_insert_own_posts" ON posts FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "auth_update_own_posts" ON posts;
CREATE POLICY "auth_update_own_posts" ON posts FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "auth_delete_own_posts" ON posts;
CREATE POLICY "auth_delete_own_posts" ON posts FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

CREATE INDEX IF NOT EXISTS idx_posts_created_at ON posts(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_posts_user_id ON posts(user_id);

-- Backfill profiles for existing users
INSERT INTO profiles (id, display_name)
SELECT id, split_part(email, '@', 1)
FROM auth.users
WHERE id NOT IN (SELECT id FROM profiles)
ON CONFLICT (id) DO NOTHING;

-- Auto-create profile on signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
BEGIN
  INSERT INTO public.profiles (id, display_name)
  VALUES (new.id, split_part(new.email, '@', 1))
  ON CONFLICT (id) DO NOTHING;
  RETURN new;
END;
$$;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();
