/*
# Add course thumbnails

1. Overview
   Adds a thumbnail image to each course so members can visually identify
   courses in the classroom grid. Thumbnails are uploaded by admins (or
   members with manage_content) and stored in a public Supabase Storage
   bucket.

2. Modified Tables
   - `courses`
     - thumbnail_url (text, nullable) — public URL of the cover image.

3. New Storage Bucket
   - `course-thumbnails` — public read, authenticated write. Stores cover
     images keyed by course id.

4. Security
   - Storage bucket policies:
       SELECT (read)  — public (anon + authenticated) so cover images load
                        for all signed-in members.
       INSERT/UPDATE  — authenticated only (manage_content is enforced at
                        the RLS table level for the courses row, so the
                        bucket can stay open to authenticated writes; the
                        courses table UPDATE policy already gates this).
       DELETE         — authenticated.
   - No changes to existing table RLS policies. The courses UPDATE policy
     already requires manage_content, so only permitted members can write
     thumbnail_url.
*/

ALTER TABLE courses
  ADD COLUMN IF NOT EXISTS thumbnail_url text;

-- Storage bucket for course cover images
INSERT INTO storage.buckets (id, name, public)
VALUES ('course-thumbnails', 'course-thumbnails', true)
ON CONFLICT (id) DO NOTHING;

-- Public read
DROP POLICY IF EXISTS "public_read_course_thumbnails" ON storage.objects;
CREATE POLICY "public_read_course_thumbnails" ON storage.objects
  FOR SELECT TO anon, authenticated
  USING (bucket_id = 'course-thumbnails');

-- Authenticated insert
DROP POLICY IF EXISTS "auth_insert_course_thumbnails" ON storage.objects;
CREATE POLICY "auth_insert_course_thumbnails" ON storage.objects
  FOR INSERT TO authenticated
  WITH CHECK (bucket_id = 'course-thumbnails');

-- Authenticated update
DROP POLICY IF EXISTS "auth_update_course_thumbnails" ON storage.objects;
CREATE POLICY "auth_update_course_thumbnails" ON storage.objects
  FOR UPDATE TO authenticated
  USING (bucket_id = 'course-thumbnails')
  WITH CHECK (bucket_id = 'course-thumbnails');

-- Authenticated delete
DROP POLICY IF EXISTS "auth_delete_course_thumbnails" ON storage.objects;
CREATE POLICY "auth_delete_course_thumbnails" ON storage.objects
  FOR DELETE TO authenticated
  USING (bucket_id = 'course-thumbnails');
