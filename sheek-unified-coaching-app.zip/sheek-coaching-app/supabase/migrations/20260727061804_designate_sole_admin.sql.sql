/*
# Designate sole admin (sheek24kustoms@gmail.com)

1. Overview
   Restricts admin access to a single designated member:
   sheek24kustoms@gmail.com. All other members are set to is_admin=false so
   only this one account sees the Admin section under Settings.

2. Modified Tables
   - `profiles`
     - is_admin set to true ONLY for the row whose email matches
       sheek24kustoms@gmail.com; set to false for every other row.

3. Notes
   - The admin still has status='approved' so she can see the app normally.
   - The Admin panel is surfaced inside the Settings screen (not as a
     separate top-level tab) and only renders when the logged-in member's
     profile has is_admin=true.
*/

UPDATE profiles
SET is_admin = (email = 'sheek24kustoms@gmail.com');
