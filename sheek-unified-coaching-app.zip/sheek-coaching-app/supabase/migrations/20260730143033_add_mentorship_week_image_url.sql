/*
# Add image_url to mentorship_week_content

1. Modified Tables
- `mentorship_week_content`
  - ADD COLUMN `image_url` (text, nullable) — public URL of an uploaded thumbnail image for the week card banner.
2. Security
- No RLS policy changes. Existing policies on `mentorship_week_content` already cover SELECT/INSERT/UPDATE/DELETE.
3. Notes
- Idempotent: uses `IF NOT EXISTS` guard.
- The column is nullable so existing rows are unaffected; weeks without a thumbnail fall back to a gradient banner.
*/

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema = 'public' AND table_name = 'mentorship_week_content' AND column_name = 'image_url'
  ) THEN
    ALTER TABLE mentorship_week_content ADD COLUMN image_url text;
  END IF;
END $$;
