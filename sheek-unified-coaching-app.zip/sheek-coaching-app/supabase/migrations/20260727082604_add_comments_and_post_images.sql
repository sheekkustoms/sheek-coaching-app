/*
# Add comments, replies, and image support to Community

1. Overview
   This migration adds threaded comments (with one level of replies) to community
   posts, plus the ability to attach a single image to both posts and comments.

2. New Tables
   - `comments`
     - id (uuid, PK)
     - post_id (uuid, NOT NULL, REFERENCES posts(id) ON DELETE CASCADE)
     - user_id (uuid, NOT NULL DEFAULT auth.uid(), REFERENCES profiles(id) ON DELETE CASCADE)
     - body (text, not null)
     - parent_id (uuid, nullable, REFERENCES comments(id) ON DELETE CASCADE)
       — NULL means it's a top-level comment on the post; a non-NULL value means
         it's a reply to another comment (one level deep).
     - image_url (text, nullable) — public URL of an uploaded image
     - created_at (timestamptz, default now())

3. Modified Tables
   - `posts`
     - ADD COLUMN image_url (text, nullable) — public URL of an uploaded image

4. Storage
   - Creates a public bucket `community-images` for post and comment images.

5. Security (RLS)
   - comments: authenticated SELECT (shared feed); owner-scoped INSERT/UPDATE/DELETE.
   - Storage policies: authenticated users can upload to and read from
     `community-images`.

6. Indexes
   - idx_comments_post_id on comments(post_id)
   - idx_comments_parent_id on comments(parent_id)
   - idx_comments_created_at on comments(created_at)
*/

-- Add image_url to posts
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema = 'public' AND table_name = 'posts' AND column_name = 'image_url'
  ) THEN
    ALTER TABLE posts ADD COLUMN image_url text;
  END IF;
END $$;

-- Create comments table
CREATE TABLE IF NOT EXISTS comments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  post_id uuid NOT NULL REFERENCES posts(id) ON DELETE CASCADE,
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES profiles(id) ON DELETE CASCADE,
  body text NOT NULL,
  parent_id uuid REFERENCES comments(id) ON DELETE CASCADE,
  image_url text,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE comments ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "auth_select_comments" ON comments;
CREATE POLICY "auth_select_comments" ON comments FOR SELECT
  TO authenticated USING (true);

DROP POLICY IF EXISTS "auth_insert_own_comments" ON comments;
CREATE POLICY "auth_insert_own_comments" ON comments FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "auth_update_own_comments" ON comments;
CREATE POLICY "auth_update_own_comments" ON comments FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "auth_delete_own_comments" ON comments;
CREATE POLICY "auth_delete_own_comments" ON comments FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

CREATE INDEX IF NOT EXISTS idx_comments_post_id ON comments(post_id);
CREATE INDEX IF NOT EXISTS idx_comments_parent_id ON comments(parent_id);
CREATE INDEX IF NOT EXISTS idx_comments_created_at ON comments(created_at);

-- Create community-images storage bucket
INSERT INTO storage.buckets (id, name, public)
VALUES ('community-images', 'community-images', true)
ON CONFLICT (id) DO NOTHING;

-- Storage policies for community-images
DROP POLICY IF EXISTS "community_images_read" ON storage.objects;
CREATE POLICY "community_images_read" ON storage.objects
  FOR SELECT TO authenticated
  USING (bucket_id = 'community-images');

DROP POLICY IF EXISTS "community_images_upload" ON storage.objects;
CREATE POLICY "community_images_upload" ON storage.objects
  FOR INSERT TO authenticated
  WITH CHECK (bucket_id = 'community-images');

DROP POLICY IF EXISTS "community_images_update_own" ON storage.objects;
CREATE POLICY "community_images_update_own" ON storage.objects
  FOR UPDATE TO authenticated
  USING (bucket_id = 'community-images' AND owner = auth.uid())
  WITH CHECK (bucket_id = 'community-images' AND owner = auth.uid());

DROP POLICY IF EXISTS "community_images_delete_own" ON storage.objects;
CREATE POLICY "community_images_delete_own" ON storage.objects
  FOR DELETE TO authenticated
  USING (bucket_id = 'community-images' AND owner = auth.uid());
