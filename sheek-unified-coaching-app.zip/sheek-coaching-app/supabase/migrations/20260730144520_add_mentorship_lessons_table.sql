/*
# Add mentorship_lessons table

1. Purpose
   Break each mentorship week into discrete, clickable lessons instead of one
   long document.  Each lesson has a title, subtitle, type, and three structured
   bullet sections ("What We'll Figure Out", "You Will Leave With", "Come Ready
   to Share") so content is scannable and focused — never a wall of text.

2. New Table: mentorship_lessons
   - id            uuid PK
   - week_number   int  — which week (1-12) this lesson belongs to
   - position      int  — display order within the week
   - title         text — lesson headline
   - subtitle      text — short description shown on the card
   - lesson_type   text — 'strategy' | 'worksheet' | 'video' | 'reflection'
   - figure_out    text[] — "What We'll Figure Out" bullet list
   - leave_with    text[] — "You Will Leave With" bullet list
   - come_ready    text[] — "Come Ready to Share" prompts (nullable)
   - body_html     text   — optional rich content shown inside the lesson
   - video_url     text   — optional Vimeo embed URL
   - pdf_url       text   — optional downloadable PDF URL
   - created_at    timestamptz
   - updated_at    timestamptz

3. Security
   - RLS enabled.
   - All authenticated users can SELECT (shared curriculum content).
   - All authenticated users can INSERT/UPDATE/DELETE (admin-only enforced in UI;
     matches existing mentorship_week_content pattern).
*/

CREATE TABLE IF NOT EXISTS mentorship_lessons (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  week_number int  NOT NULL,
  position     int  NOT NULL DEFAULT 0,
  title        text NOT NULL,
  subtitle     text,
  lesson_type  text NOT NULL DEFAULT 'strategy',
  figure_out   text[] NOT NULL DEFAULT '{}',
  leave_with   text[] NOT NULL DEFAULT '{}',
  come_ready   text[] DEFAULT '{}',
  body_html    text,
  video_url    text,
  pdf_url      text,
  created_at   timestamptz NOT NULL DEFAULT now(),
  updated_at   timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_mentorship_lessons_week
  ON mentorship_lessons (week_number, position);

ALTER TABLE mentorship_lessons ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "read_mentorship_lessons" ON mentorship_lessons;
CREATE POLICY "read_mentorship_lessons"
  ON mentorship_lessons FOR SELECT
  TO authenticated USING (true);

DROP POLICY IF EXISTS "insert_mentorship_lessons" ON mentorship_lessons;
CREATE POLICY "insert_mentorship_lessons"
  ON mentorship_lessons FOR INSERT
  TO authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "update_mentorship_lessons" ON mentorship_lessons;
CREATE POLICY "update_mentorship_lessons"
  ON mentorship_lessons FOR UPDATE
  TO authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "delete_mentorship_lessons" ON mentorship_lessons;
CREATE POLICY "delete_mentorship_lessons"
  ON mentorship_lessons FOR DELETE
  TO authenticated USING (true);
