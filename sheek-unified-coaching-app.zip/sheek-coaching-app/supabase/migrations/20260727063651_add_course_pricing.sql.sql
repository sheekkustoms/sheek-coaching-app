/*
# Add per-course pricing and purchases

1. Overview
   Adds an optional one-time price to each course. Courses with price = 0 (or
   null) are included free with membership. Courses with price > 0 are locked
   behind a one-time Stripe payment. When a member pays, a row is recorded in
   `course_purchases` and the course is unlocked for that user permanently.

2. Modified Tables
   - `courses`
     - price (integer, nullable, default 0) — price in cents. 0 or null means
       the course is free with membership. > 0 means a one-time payment is
       required. Stored in cents to avoid floating-point money issues.

3. New Tables
   - `course_purchases`
     - id (uuid, primary key)
     - user_id (uuid, FK -> auth.users ON DELETE CASCADE, default auth.uid())
     - course_id (uuid, FK -> courses ON DELETE CASCADE)
     - stripe_session_id (text, unique) — the Stripe Checkout Session ID that
       created this purchase, for idempotency on webhook retries.
     - amount_paid (integer) — cents paid at time of purchase (snapshot).
     - purchased_at (timestamptz, default now())
   - Unique constraint on (user_id, course_id) so a member can only purchase
     a course once.

4. Indexes
   - `course_purchases(user_id)` for fast "my purchases" lookups.
   - `course_purchases(course_id)` for fast "who bought this" lookups.

5. Security (RLS)
   - `course_purchases` is owner-scoped: each authenticated user can only
     read their own purchase records. INSERT is allowed for authenticated
     users (the webhook edge function uses the service-role key which
     bypasses RLS, but we also allow authenticated inserts so the frontend
     could record a purchase if needed). UPDATE and DELETE are owner-scoped.
*/

ALTER TABLE courses
  ADD COLUMN IF NOT EXISTS price integer DEFAULT 0;

CREATE TABLE IF NOT EXISTS course_purchases (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  course_id uuid NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
  stripe_session_id text UNIQUE,
  amount_paid integer,
  purchased_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE course_purchases ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_purchases" ON course_purchases;
CREATE POLICY "select_own_purchases" ON course_purchases FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_purchases" ON course_purchases;
CREATE POLICY "insert_own_purchases" ON course_purchases FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_purchases" ON course_purchases;
CREATE POLICY "update_own_purchases" ON course_purchases FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_purchases" ON course_purchases;
CREATE POLICY "delete_own_purchases" ON course_purchases FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

CREATE UNIQUE INDEX IF NOT EXISTS idx_course_purchases_user_course
  ON course_purchases(user_id, course_id);

CREATE INDEX IF NOT EXISTS idx_course_purchases_user_id
  ON course_purchases(user_id);

CREATE INDEX IF NOT EXISTS idx_course_purchases_course_id
  ON course_purchases(course_id);
