-- ── 1. BEFORE UPDATE trigger: protect privileged columns on profiles ──
-- Non-admin, non-service-role updates silently reset is_admin, tier,
-- status, and permissions to their existing values so a legitimate
-- profile edit (display name, avatar) still succeeds.

CREATE OR REPLACE FUNCTION protect_profile_privileged_columns()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER SET search_path TO 'public'
AS $$
BEGIN
  -- service role has no auth.uid(); admins return true from is_admin().
  IF NOT (is_admin() OR auth.uid() IS NULL) THEN
    NEW.is_admin     := OLD.is_admin;
    NEW.tier         := OLD.tier;
    NEW.status       := OLD.status;
    NEW.permissions  := OLD.permissions;
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS protect_profile_privileged_columns ON profiles;
CREATE TRIGGER protect_profile_privileged_columns
  BEFORE UPDATE ON profiles
  FOR EACH ROW
  EXECUTE FUNCTION protect_profile_privileged_columns();

-- ── 2. course_purchases: restrict INSERT/UPDATE to service role only ──
-- Users keep SELECT on their own rows; they can no longer insert or
-- update purchase records (only the Stripe webhook / service role can).
DROP POLICY IF EXISTS insert_own_purchases ON course_purchases;
DROP POLICY IF EXISTS update_own_purchases ON course_purchases;

-- ── 3. mentorship_subscriptions: restrict INSERT/UPDATE to service role ──
DROP POLICY IF EXISTS insert_own_mentorship_sub ON mentorship_subscriptions;
DROP POLICY IF EXISTS update_own_mentorship_sub ON mentorship_subscriptions;
