-- Allow authenticated users to upload thumbnails
CREATE POLICY "allow_upload_thumbnails" ON storage.objects
  FOR INSERT TO authenticated
  WITH CHECK (bucket_id = 'video-thumbnails');

-- Allow public read of thumbnails
CREATE POLICY "allow_read_thumbnails" ON storage.objects
  FOR SELECT TO anon, authenticated
  USING (bucket_id = 'video-thumbnails');

-- Allow authenticated users to update/overwrite thumbnails
CREATE POLICY "allow_update_thumbnails" ON storage.objects
  FOR UPDATE TO authenticated
  USING (bucket_id = 'video-thumbnails')
  WITH CHECK (bucket_id = 'video-thumbnails');