import "jsr:@supabase/functions-js/edge-runtime.d.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

/**
 * Extract the numeric Vimeo video ID from a URL, embed code, or raw ID.
 */
function extractVideoId(input: string): string | null {
  const m = input.match(/video\/(\d+)/);
  if (m) return m[1];
  const m2 = input.match(/vimeo\.com\/(\d+)/);
  if (m2) return m2[1];
  if (/^\d+$/.test(input.trim())) return input.trim();
  return null;
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const url = new URL(req.url);
    const videoUrl = url.searchParams.get("url");
    const videoIdParam = url.searchParams.get("id");
    const imageId = url.searchParams.get("image");
    const proxyUrl = url.searchParams.get("proxy");

    // --- Video proxy mode: stream a video file with CORS headers ---
    // Used by the client to capture a frame from a Vimeo video URL via canvas.
    if (proxyUrl) {
      // Only allow proxying Vimeo CDN URLs
      if (!proxyUrl.includes('vimeocdn.com') && !proxyUrl.includes('vimeo.com')) {
        return new Response(JSON.stringify({ error: "Only Vimeo URLs can be proxied" }), {
          status: 403,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      const proxyRes = await fetch(proxyUrl, {
        headers: { Accept: "*/*" },
      });
      if (!proxyRes.ok || !proxyRes.body) {
        return new Response(null, { status: proxyRes.status, headers: corsHeaders });
      }

      return new Response(proxyRes.body, {
        status: 200,
        headers: {
          ...corsHeaders,
          "Cache-Control": "public, max-age=2592000",
          "Content-Type": proxyRes.headers.get("content-type") ?? "application/octet-stream",
          "Cross-Origin-Resource-Policy": "cross-origin",
          "Access-Control-Allow-Credentials": "true",
        },
      });
    }

    // --- Video-ID thumbnail mode: proxy a vumbnail.com image through our own origin ---
    // Works for public AND private/unlisted videos. The `vid` param is the Vimeo VIDEO ID (not CDN image ID).
    if (imageId) {
      if (!/^\d+$/.test(imageId)) {
        return new Response(JSON.stringify({ error: "Invalid image id" }), {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      // Try vumbnail.com first (works for all videos including private)
      const vumbRes = await fetch(`https://vumbnail.com/${imageId}.jpg`, {
        headers: { Accept: "image/*" },
      });
      if (vumbRes.ok && vumbRes.body) {
        return new Response(vumbRes.body, {
          status: 200,
          headers: {
            ...corsHeaders,
            "Cache-Control": "public, max-age=2592000",
            "Content-Type": vumbRes.headers.get("content-type") ?? "image/jpeg",
            "Cross-Origin-Resource-Policy": "cross-origin",
          },
        });
      }

      // Fallback: try Vimeo CDN directly (works for public videos)
      const imageResponse = await fetch(`https://i.vimeocdn.com/video/${imageId}.jpg`, {
        headers: { Accept: "image/*" },
      });
      if (!imageResponse.ok || !imageResponse.body) {
        return new Response(null, { status: imageResponse.status, headers: corsHeaders });
      }

      return new Response(imageResponse.body, {
        status: 200,
        headers: {
          ...corsHeaders,
          "Cache-Control": "public, max-age=2592000",
          "Content-Type": imageResponse.headers.get("content-type") ?? "image/jpeg",
          "Cross-Origin-Resource-Policy": "cross-origin",
        },
      });
    }

    // --- Metadata mode: resolve a Vimeo URL/embed to oEmbed data ---
    let vimeoUrl = "";
    let videoId: string | null = null;

    if (videoUrl) {
      vimeoUrl = videoUrl;
      videoId = extractVideoId(videoUrl);
    } else if (videoIdParam) {
      videoId = extractVideoId(videoIdParam) ?? (/^\d+$/.test(videoIdParam) ? videoIdParam : null);
      vimeoUrl = videoId ? `https://vimeo.com/${videoId}` : videoIdParam;
    } else {
      return new Response(JSON.stringify({ error: "Missing url or id parameter" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Try the oEmbed API first (works for public videos)
    const oembedUrl = `https://vimeo.com/api/oembed.json?url=${encodeURIComponent(vimeoUrl)}`;
    const res = await fetch(oembedUrl, { headers: { Accept: "application/json" } });

    if (res.ok) {
      const data = await res.json();
      const thumbId = data.thumbnail_url?.match(/video\/(\d+)/)?.[1];
      return new Response(
        JSON.stringify({
          thumbnail_url: thumbId
            ? `https://${url.host}/functions/v1/vimeo-thumbnail?image=${thumbId}`
            : null,
          title: data.title ?? null,
          embed_html: data.html ?? null,
        }),
        { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } },
      );
    }

    // oEmbed failed (private/unlisted video). Try the player config endpoint
    // which sometimes includes a thumbnail for unlisted videos.
    if (videoId) {
      try {
        const configRes = await fetch(`https://player.vimeo.com/video/${videoId}/config`, {
          headers: { Accept: "application/json" },
        });
        if (configRes.ok) {
          const config = await configRes.json();
          const thumbs = config?.video?.thumbs;
          if (thumbs) {
            // pick the largest thumb
            const sizes = Object.keys(thumbs).sort((a, b) => Number(b) - Number(a));
            for (const size of sizes) {
              const thumbUrl = thumbs[size];
              if (thumbUrl) {
                const thumbId = thumbUrl.match(/video\/(\d+)/)?.[1];
                if (thumbId) {
                  return new Response(
                    JSON.stringify({
                      thumbnail_url: `https://${url.host}/functions/v1/vimeo-thumbnail?image=${thumbId}`,
                      title: config?.video?.title ?? null,
                      embed_html: null,
                    }),
                    { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } },
                  );
                }
                // If the thumb URL is already a full URL, proxy it
                if (thumbUrl.startsWith("http")) {
                  return new Response(
                    JSON.stringify({
                      thumbnail_url: thumbUrl,
                      title: config?.video?.title ?? null,
                      embed_html: null,
                    }),
                    { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } },
                  );
                }
              }
            }
          }
        }
      } catch {
        // fall through
      }
    }

    // No thumbnail available — return null so the client uses its fallback
    return new Response(
      JSON.stringify({ thumbnail_url: null, title: null, embed_html: null }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );
  } catch (err) {
    return new Response(
      JSON.stringify({ error: err instanceof Error ? err.message : "Unknown error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );
  }
});
