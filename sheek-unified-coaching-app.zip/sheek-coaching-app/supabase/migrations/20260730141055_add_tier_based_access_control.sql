/*
# Tier-based access control: events category, mentorship-only community, mentorship members

1. Overview
   Restructures the app into two navigation tiers. The top-level nav shows Classroom,
   Calendar (general events only), Mentorship, and Mentor Studio (admin only). Community
   and Members are removed from the top-level nav and become nested sub-tabs inside the
   Mentorship mini-app, visible only to mentorship-tier members and admins.

   All filtering is enforced at the database level via RLS — a $99/mo member querying
   posts, mentorship events, or the mentorship member list gets nothing back or a policy
   violation, not just a hidden UI button.

2. Modified Tables
   - `events`
     - ADD COLUMN `category` text NOT NULL DEFAULT 'general'
     - All existing rows backfilled to 'general'.
   - `posts` — RLS tightened: SELECT and INSERT restricted to mentorship-tier + admin.
   - `comments` — RLS tightened: SELECT and INSERT restricted to mentorship-tier + admin
     (comments only exist on posts, which are now mentorship-only).
   - `events` — RLS updated: general events visible to all authenticated users;
     mentorship events visible only to mentorship-tier + admin.

3. New Functions
   - `get_mentorship_members()` — SECURITY DEFINER function that returns profiles for
     mentorship-tier members + admins only. Raises an exception if the caller is not
     mentorship-tier or admin, so a $99/mo member calling it directly gets a database
     permission error.

4. Security (RLS)
   - posts: SELECT/INSERT/UPDATE/DELETE restricted to mentorship-tier + admin (was: all
     authenticated). Delete also allowed for admins (moderation).
   - comments: SELECT/INSERT/UPDATE/DELETE restricted to mentorship-tier + admin. Delete
     also allowed for admins.
   - events: SELECT — general events visible to all authenticated; mentorship events
     visible only to mentorship-tier + admin. INSERT/UPDATE/DELETE — general events by
     any authenticated user (own events); mentorship events by mentorship-tier + admin.
   - Helper EXISTS subqueries check profiles.tier = 'mentorship' OR profiles.is_admin.

5. Notes
   - profiles table SELECT stays open to all authenticated (needed for auth, classroom,
     post author display names, etc.).
   - The get_mentorship_members() function uses SECURITY DEFINER to bypass RLS on
     profiles, but guards access with an explicit tier check that raises an exception.
*/

-- ============================================================
-- 1. Add category column to events
-- ============================================================

ALTER TABLE events ADD COLUMN IF NOT EXISTS category text NOT NULL DEFAULT 'general';

-- Backfill: all existing events become 'general'
UPDATE events SET category = 'general' WHERE category IS NULL OR category = '';

CREATE INDEX IF NOT EXISTS idx_events_category ON events (category);

-- ============================================================
-- 2. Posts RLS — mentorship-tier + admin only
-- ============================================================

DROP POLICY IF EXISTS "auth_select_posts" ON posts;
CREATE POLICY "auth_select_posts" ON posts FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND (profiles.tier = 'mentorship' OR profiles.is_admin = true)
    )
  );

DROP POLICY IF EXISTS "auth_insert_own_posts" ON posts;
CREATE POLICY "auth_insert_own_posts" ON posts FOR INSERT
  TO authenticated
  WITH CHECK (
    auth.uid() = user_id
    AND EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND (profiles.tier = 'mentorship' OR profiles.is_admin = true)
    )
  );

DROP POLICY IF EXISTS "auth_update_own_posts" ON posts;
CREATE POLICY "auth_update_own_posts" ON posts FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (
    auth.uid() = user_id
    AND EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND (profiles.tier = 'mentorship' OR profiles.is_admin = true)
    )
  );

DROP POLICY IF EXISTS "auth_delete_own_posts" ON posts;
CREATE POLICY "auth_delete_own_posts" ON posts FOR DELETE
  TO authenticated
  USING (
    auth.uid() = user_id
    OR EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.is_admin = true
    )
  );

-- ============================================================
-- 3. Comments RLS — mentorship-tier + admin only
-- ============================================================

DROP POLICY IF EXISTS "auth_select_comments" ON comments;
CREATE POLICY "auth_select_comments" ON comments FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND (profiles.tier = 'mentorship' OR profiles.is_admin = true)
    )
  );

DROP POLICY IF EXISTS "auth_insert_own_comments" ON comments;
CREATE POLICY "auth_insert_own_comments" ON comments FOR INSERT
  TO authenticated
  WITH CHECK (
    auth.uid() = user_id
    AND EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND (profiles.tier = 'mentorship' OR profiles.is_admin = true)
    )
  );

DROP POLICY IF EXISTS "auth_update_own_comments" ON comments;
CREATE POLICY "auth_update_own_comments" ON comments FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (
    auth.uid() = user_id
    AND EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND (profiles.tier = 'mentorship' OR profiles.is_admin = true)
    )
  );

DROP POLICY IF EXISTS "auth_delete_own_comments" ON comments;
CREATE POLICY "auth_delete_own_comments" ON comments FOR DELETE
  TO authenticated
  USING (
    auth.uid() = user_id
    OR EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.is_admin = true
    )
  );

-- ============================================================
-- 4. Events RLS — general visible to all, mentorship restricted
-- ============================================================

DROP POLICY IF EXISTS "select_own_events" ON events;
CREATE POLICY "select_events" ON events FOR SELECT
  TO authenticated
  USING (
    category = 'general'
    OR EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND (profiles.tier = 'mentorship' OR profiles.is_admin = true)
    )
  );

DROP POLICY IF EXISTS "insert_own_events" ON events;
CREATE POLICY "insert_events" ON events FOR INSERT
  TO authenticated
  WITH CHECK (
    auth.uid() = user_id
    AND (
      category = 'general'
      OR EXISTS (
        SELECT 1 FROM profiles
        WHERE profiles.id = auth.uid()
        AND (profiles.tier = 'mentorship' OR profiles.is_admin = true)
      )
    )
  );

DROP POLICY IF EXISTS "update_own_events" ON events;
CREATE POLICY "update_events" ON events FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (
    auth.uid() = user_id
    AND (
      category = 'general'
      OR EXISTS (
        SELECT 1 FROM profiles
        WHERE profiles.id = auth.uid()
        AND (profiles.tier = 'mentorship' OR profiles.is_admin = true)
      )
    )
  );

DROP POLICY IF EXISTS "delete_own_events" ON events;
CREATE POLICY "delete_events" ON events FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- ============================================================
-- 5. get_mentorship_members() — SECURITY DEFINER function
-- ============================================================

CREATE OR REPLACE FUNCTION public.get_mentorship_members()
RETURNS TABLE (
  id uuid,
  display_name text,
  email text,
  avatar_url text,
  status text,
  is_admin boolean,
  permissions jsonb,
  tier text,
  created_at timestamptz
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Guard: only mentorship-tier or admin can call this
  IF NOT EXISTS (
    SELECT 1 FROM profiles
    WHERE profiles.id = auth.uid()
    AND (profiles.tier = 'mentorship' OR profiles.is_admin = true)
  ) THEN
    RAISE EXCEPTION 'Access denied: mentorship tier required' USING ERRCODE = '42501';
  END IF;

  RETURN QUERY
  SELECT
    p.id, p.display_name, p.email, p.avatar_url, p.status,
    p.is_admin, p.permissions, p.tier, p.created_at
  FROM profiles p
  WHERE p.status = 'approved'
    AND (p.tier = 'mentorship' OR p.is_admin = true)
  ORDER BY p.created_at DESC;
END;
$$;

GRANT EXECUTE ON FUNCTION public.get_mentorship_members() TO authenticated;